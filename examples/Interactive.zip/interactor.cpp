#include "testlib.h"
#include <iostream>
int main(int argc,char**argv){registerInteraction(argc,argv);for(int i=0;i<3;i++){int x=inf.readInt();std::cout<<x<<std::endl;int y=ouf.readInt();if(y!=2*x)quitf(_wa,"expected double");}quitf(_ok,"three rounds accepted");}