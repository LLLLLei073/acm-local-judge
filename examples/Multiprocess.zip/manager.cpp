#include "acm_manager.hpp"
#include <algorithm>
#include <fstream>
#include <sstream>
#include <vector>
using Value = unsigned long long;
bool integer(const std::string& text, long long& value) {
    std::istringstream in(text);
    if (!(in >> value)) return false;
    in >> std::ws;
    return in.eof();
}
std::string array_line(const std::vector<Value>& values) {
    std::ostringstream out;
    for (size_t i = 0; i < values.size(); ++i) out << values[i] << (i + 1 == values.size() ? '\n' : ' ');
    return out.str();
}
int main() {
    auto init = acm::receive();
    if (init.value("processCount", 0) != 2) { acm::verdict("Judge Error", "this problem requires two roles"); return 0; }
    std::ifstream in(init["inputPath"].get<std::string>());
    int n;
    if (!(in >> n) || n < 1 || n > 200000) { acm::verdict("Judge Error", "invalid input n"); return 0; }
    std::vector<Value> a(n), b(n);
    for (auto* values : {&a, &b}) for (auto& x : *values)
        if (!(in >> x) || x > 1000000000000000000ULL) { acm::verdict("Judge Error", "invalid input value"); return 0; }
    // Keep stdin open: each role must wait for messages from its peer.
    acm::send(0, std::to_string(n) + "\n" + array_line(a));
    acm::send(1, std::to_string(n) + "\n" + array_line(b));
    std::sort(a.begin(), a.end());
    std::sort(b.begin(), b.end());
    const int expected = a == b ? 1 : 0;
    std::string pending[2], header;
    size_t scanned[2] = {};
    bool exited[2] = {};
    // 0: role 0 header; 1: sorted array; 2: role 1 result; 3: role 0 result; 4: exits.
    int stage = 0;
    while (!exited[0] || !exited[1]) {
        auto event = acm::receive();
        const auto type = event.value("type", "");
        if (type == "eof") return 3;
        int id = event.at("id").get<int>();
        if (type == "output") {
            pending[id] += acm::decode(event.at("data").get<std::string>());
            for (;;) {
                auto end = pending[id].find('\n', scanned[id]);
                if (end == std::string::npos) { scanned[id] = pending[id].size(); break; }
                std::string line = pending[id].substr(0, end + 1);
                pending[id].erase(0, end + 1); scanned[id] = 0;
                long long value;
                if (id == 0 && stage == 0) {
                    if (!integer(line, value) || value != n) { acm::verdict("WA", "role 0: wrong n"); return 0; }
                    header = line; stage = 1;
                } else if (id == 0 && stage == 1) {
                    std::istringstream values(line);
                    for (auto x : a) {
                        Value actual;
                        if (!(values >> actual) || actual != x) { acm::verdict("WA", "role 0: expected sorted original multiset"); return 0; }
                    }
                    values >> std::ws;
                    if (!values.eof()) { acm::verdict("WA", "role 0: extra array tokens"); return 0; }
                    // Forward original bytes, including whitespace and CRLF.
                    acm::send(1, header + line); stage = 2;
                } else if (id == 1 && stage == 2) {
                    if (!integer(line, value) || value != expected) { acm::verdict("WA", "role 1: incorrect final answer"); return 0; }
                    acm::send(0, line); acm::close(1); stage = 3;
                } else if (id == 0 && stage == 3) {
                    if (!integer(line, value) || value != expected) { acm::verdict("WA", "role 0: final answer must agree with role 1"); return 0; }
                    acm::close(0); stage = 4;
                } else { acm::verdict("WA", "unexpected output or extra output"); return 0; }
            }
        } else if (type == "exit") {
            // The engine owns RE/TLE/MLE/OLE, rather than this protocol checker.
            if (event.value("verdict", "") != "AC") return 0;
            if (!pending[id].empty() || (id == 0 ? stage < 4 : stage < 3)) {
                acm::verdict("WA", "role exited before completing its protocol"); return 0;
            }
            exited[id] = true;
        }
    }
    acm::verdict("AC", "both roles completed the relay and agreed on the correct answer");
}