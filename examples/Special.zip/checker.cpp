#include "testlib.h"
#include <cmath>
int main(int argc,char**argv){registerTestlibCmd(argc,argv);double expected=ans.readDouble();double actual=ouf.readDouble();if(!ouf.seekEof())quitf(_pe,"extra output");if(std::abs(actual-expected)<=1e-6*std::max(1.0,std::abs(expected)))quitf(_ok,"within tolerance");quitf(_wa,"outside tolerance");}